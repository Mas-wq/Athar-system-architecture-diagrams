// Minimal Excalidraw element builder + library instantiation
const fs=require('fs');
const LIBDIR='/mnt/user-data/attachments/2d73d9e9-1039-5c24-8b69-bc4329bd647b/';
let n=0, sd=1337;
const rnd=()=>{ sd=(sd*1103515245+12345)&0x7fffffff; return sd; };
const nid=()=>'a'+(++n).toString(36)+Math.abs(rnd()).toString(36);
const C={ink:'#1e1e1e',gray:'#868e96',blue:'#4a90d9',green:'#43a35a',red:'#e0605c',
  yellow:'#fff3bf',blueF:'#d0ebff',greenF:'#d3f9d8',grayF:'#f1f3f5',redF:'#ffe3e3',white:'#ffffff',orangeF:'#ffe8cc'};
function base(type,o){
  return Object.assign({id:nid(),type,x:0,y:0,width:0,height:0,angle:0,strokeColor:C.ink,backgroundColor:'transparent',
    fillStyle:'solid',strokeWidth:2,strokeStyle:'solid',roughness:1,opacity:100,groupIds:[],frameId:null,roundness:null,
    seed:rnd(),version:1,versionNonce:rnd(),isDeleted:false,boundElements:[],updated:1700000000000,link:null,locked:false},o);
}
class Doc{
  constructor(){ this.els=[]; this.byId={}; }
  add(e){ this.els.push(e); this.byId[e.id]=e; return e; }
  rect(x,y,w,h,o={}){ return this.add(base('rectangle',{x,y,width:w,height:h,roundness:o.sharp?null:{type:3},...o})); }
  ellipse(x,y,w,h,o={}){ return this.add(base('ellipse',{x,y,width:w,height:h,roundness:{type:2},...o})); }
  text(x,y,text,fs=24,o={}){
    const lines=text.split('\n'); const w=o.width||Math.ceil(Math.max(...lines.map(l=>l.length))*fs*0.6);
    const h=Math.ceil(lines.length*fs*1.25);
    const align=o.textAlign||'left';
    let px=x; if(align==='center') px=x-w/2; else if(align==='right') px=x-w;
    return this.add(base('text',{x:px,y,width:w,height:h,text,originalText:text,fontSize:fs,fontFamily:1,textAlign:align,
      verticalAlign:'top',baseline:Math.round(fs*0.9),containerId:null,lineHeight:1.25,autoResize:true,strokeWidth:1,roughness:1,...o,}));
  }
  // arrow through absolute points; optional bindings {from:el,to:el}
  arrow(pts,o={}){
    const [x0,y0]=pts[0]; const rel=pts.map(p=>[p[0]-x0,p[1]-y0]);
    const xs=rel.map(p=>p[0]),ys=rel.map(p=>p[1]);
    const a=this.add(base('arrow',{x:x0,y:y0,width:Math.max(...xs)-Math.min(...xs),height:Math.max(...ys)-Math.min(...ys),points:rel,
      lastCommittedPoint:null,startBinding:null,endBinding:null,startArrowhead:o.start||null,endArrowhead:o.end===undefined?'arrow':o.end,elbowed:false,
      strokeColor:o.color||C.blue,strokeStyle:o.dash?'dashed':'solid',strokeWidth:o.w||2,roundness:null}));
    if(o.from){ a.startBinding={elementId:o.from.id,focus:0,gap:4}; o.from.boundElements.push({type:'arrow',id:a.id}); }
    if(o.to){ a.endBinding={elementId:o.to.id,focus:0,gap:4}; o.to.boundElements.push({type:'arrow',id:a.id}); }
    return a;
  }
  group(fn){ const g=nid(); const start=this.els.length; fn(); for(let i=start;i<this.els.length;i++) this.els[i].groupIds=[g,...this.els[i].groupIds]; return g; }
  // instantiate a library item scaled to width tw at (tx,ty). opts: dropText, tint, stroke
  lib(file,idx,tx,ty,tw,o={}){
    const d=JSON.parse(fs.readFileSync(LIBDIR+file,'utf8')); const items=d.libraryItems||d.library;
    let els=(Array.isArray(items[idx])?items[idx]:items[idx].elements).map(e=>JSON.parse(JSON.stringify(e)));
    if(o.dropText) els=els.filter(e=>e.type!=='text');
    const bb=els.map(e=>{ if(e.points){ const px=e.points.map(p=>p[0]),py=e.points.map(p=>p[1]);
        return [e.x+Math.min(...px),e.y+Math.min(...py),e.x+Math.max(...px),e.y+Math.max(...py)]; }
      return [e.x,e.y,e.x+e.width,e.y+e.height]; });
    const bx=Math.min(...bb.map(b=>b[0])),by=Math.min(...bb.map(b=>b[1])),bX=Math.max(...bb.map(b=>b[2])),bY=Math.max(...bb.map(b=>b[3]));
    const s=tw/(bX-bx); const gmap={}; const out=[]; const gid=nid();
    for(const e of els){
      const type=e.type==='draw'?'line':e.type;
      const ne=base(type,{});
      Object.assign(ne,{x:tx+(e.x-bx)*s,y:ty+(e.y-by)*s,width:e.width*s,height:e.height*s,angle:e.angle||0,
        strokeColor:o.stroke||(e.strokeColor==='white'?'white':C.ink),
        backgroundColor:(()=>{const b=e.backgroundColor; if(!b||b==='transparent') return 'transparent'; if(b==='white'||b==='#fff') return '#ffffff'; if(b==='black'||b==='#000000') return o.dark||C.gray; return o.tint||C.grayF;})(),
        fillStyle:'solid',strokeWidth:Math.min(e.strokeWidth||1,2),roughness:1,opacity:100,
        roundness:(e.strokeSharpness==='round'||(e.roundness))?{type:2}:null,groupIds:[gid]});
      if(e.points){ ne.points=e.points.map(p=>[p[0]*s,p[1]*s]); ne.lastCommittedPoint=null; ne.startBinding=null; ne.endBinding=null; ne.startArrowhead=null; ne.endArrowhead=null; }
      if(type==='text'){ Object.assign(ne,{text:e.text,originalText:e.text,fontSize:(e.fontSize||16)*s,fontFamily:1,textAlign:e.textAlign||'left',verticalAlign:'top',baseline:e.baseline,containerId:null,lineHeight:1.25}); }
      out.push(this.add(ne));
    }
    return {els:out,x:tx,y:ty,w:tw,h:(bY-by)*s};
  }
  json(W=1920,H=1080){
    return {type:'excalidraw',version:2,source:'https://excalidraw.com',elements:this.els,
      appState:{gridSize:null,viewBackgroundColor:'#ffffff',exportW:W,exportH:H},files:{}};
  }
}
module.exports={Doc,C,base,nid};
