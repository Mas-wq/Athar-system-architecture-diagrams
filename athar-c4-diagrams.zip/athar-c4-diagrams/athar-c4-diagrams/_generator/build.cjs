const {Doc,C,base}=require('./xl.cjs'); const fs=require('fs');
const OUT=process.argv[2]; fs.mkdirSync(OUT,{recursive:true});
const A='989b6f93-architecture-diagram-components.excalidrawlib', S='b2a60524-system-design.excalidrawlib', W='ad36ee2c-software-architecture__1_.excalidrawlib';
const G='#6b7280'; // soft gray for secondary text

function title(d,t,sub,ul=420){
  d.text(60,30,t,54,{strokeWidth:1});
  d.text(62,98,sub,26,{strokeColor:G});
  const l=d.add(base('line',{x:62,y:142,width:ul,height:6,points:[[0,0],[ul*0.33,-4],[ul*0.69,3],[ul,-2]],lastCommittedPoint:null,startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:null,strokeColor:C.blue,strokeWidth:2,roughness:2,roundness:{type:2}}));
}
// centered text lines helper
const T=(d,cx,y,t,fs,o={})=>d.text(cx,y,t,fs,{textAlign:'center',...o});
function legend(d,x,y,items){
  items.forEach(([col,txt],i)=>{ d.arrow([[x,y+i*38+14],[x+60,y+i*38+14]],{color:col}); d.text(x+78,y+i*38,txt,21,{strokeColor:G}); });
}
function actor(d,cx,y,name,sub){
  const ic=d.lib(A,6,cx-55,y,110,{dropText:true,tint:C.grayF});
  T(d,cx,y+ic.h+8,name,28); T(d,cx,y+ic.h+44,sub,21,{strokeColor:G});
  return {icon:ic,bottom:y+ic.h+70,rightX:cx+70,top:y,midY:y+ic.h/2};
}
function label(d,cx,y,t,col,fs=21){ return T(d,cx,y,t,fs,{strokeColor:col||C.ink}); }
function note(d,x,y,w,h,t,fs=22){ d.rect(x,y,w,h,{backgroundColor:C.yellow,strokeColor:'#e0b84a',strokeWidth:1,roundness:{type:3}}); T(d,x+w/2,y+(h-(t.split('\n').length*fs*1.25))/2,t,fs); }

// ======================= C1 =======================
{
  const d=new Doc(); title(d,'System Context Diagram','Athar Lost & Found Platform  ·  Designed using the C4 Model');
  const user=actor(d,170,230,'Regular User','owner · finder · bidder');
  const admin=actor(d,170,640,'Administrator','platform oversight');
  // system
  let sys;
  d.group(()=>{
    sys=d.rect(560,250,700,520,{backgroundColor:C.yellow,strokeWidth:3});
    T(d,910,275,'Athar',52); T(d,910,338,'Lost & Found Platform   [software system]',24,{strokeColor:G});
    const items=['Report lost items, post found items','AI-suggested matches (text + photos)','Ownership claims with AI-made questions','Claim chat and handover coordination','Auctions for unclaimed found items','Admin: users, statistics, auction rules'];
    items.forEach((t,i)=>{ d.ellipse(615,420+i*52+9,12,12,{backgroundColor:C.ink,strokeWidth:1}); d.text(645,420+i*52,t,26); });
  });
  // groq
  let groq;
  d.group(()=>{
    d.rect(1560,390,300,200,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white}); groq=d.els[d.els.length-1];
    d.lib(S,19,1650,402,120,{dropText:true,tint:C.blueF});
    T(d,1710,490,'Groq API',34); T(d,1710,535,'external · hosted LLM\nchat + vision models',21,{strokeColor:G});
  });
  // arrows: user
  d.arrow([[245,290],[545,365]],{to:sys,color:C.blue});
  label(d,400,242,'reports, claims,\nchats, bids',C.blue);
  d.arrow([[545,460],[250,345]],{color:C.green});
  label(d,440,452,'match suggestions,\nnotifications',C.green);
  // admin
  d.arrow([[245,690],[545,640]],{color:C.blue});
  label(d,400,642-70,'manages users,\nauction rules',C.blue);
  d.arrow([[545,740],[250,745]],{color:C.green});
  label(d,400,752,'dashboard\nstatistics',C.green);
  // groq arrows
  d.arrow([[1275,450],[1545,450]],{color:C.blue}); label(d,1410,372,'descriptions + photos\n(HTTPS, API key)',C.blue);
  d.arrow([[1545,540],[1275,540]],{color:C.green}); label(d,1410,555,'match scores, claim\nquestions, chat replies',C.green);
  note(d,560,830,700,76,'AI only suggests — the finder makes\nthe final ownership decision.',26);
  legend(d,60,930,[[C.blue,'request / data sent'],[C.green,'result returned']]);
  d.text(560,930,'Guests (not signed in) can browse public lists through the same web app.',21,{strokeColor:G});
  fs.writeFileSync(OUT+'/01-system-context.excalidraw',JSON.stringify(d.json(),null,1));
}

// ======================= C2 =======================
{
  const d=new Doc(); title(d,'Container Diagram','Athar Lost & Found Platform  ·  Designed using the C4 Model');
  const user=actor(d,140,230,'Regular User','owner · finder · bidder');
  const admin=actor(d,140,600,'Administrator','platform oversight');
  // boundary
  d.rect(320,190,1260,790,{strokeStyle:'dashed',strokeColor:C.gray,strokeWidth:2});
  d.text(345,202,'Athar Platform   [software system]',24,{strokeColor:G});
  let web,api,db,files;
  d.group(()=>{
    web=d.rect(360,340,300,330,{backgroundColor:C.blueF});
    d.lib(W,5,435,358,150,{tint:C.grayF});
    T(d,510,470,'Web App',34); T(d,510,514,'React 19 · Vite · Tailwind\nReact Router · Axios',21,{strokeColor:G});
    T(d,510,582,'Single-page UI for all\nuser and admin screens',21);
  });
  d.group(()=>{
    api=d.rect(850,270,330,460,{backgroundColor:C.yellow,strokeWidth:3});
    const ic=d.lib(A,9,990,292,60,{dropText:true,tint:C.white});
    T(d,1015,292+ic.h+10,'API Server',34); T(d,1015,292+ic.h+54,'Node.js · Express 5',22,{strokeColor:G});
    ['REST under /api','JWT cookie auth + roles','Controllers + services','Cron jobs + AI job worker','Serves /uploads images'].forEach((t,i)=>T(d,1015,292+ic.h+100+i*34,t,22));
  });
  d.group(()=>{
    db=d.rect(1340,225,200,230,{backgroundColor:C.greenF});
    d.lib(W,1,1405,246,70,{tint:C.white});
    T(d,1440,380,'PostgreSQL',27); T(d,1440,414,'Drizzle ORM · pg',20,{strokeColor:G});
  });
  d.group(()=>{
    files=d.rect(1340,665,200,262,{backgroundColor:C.greenF});
    d.lib(W,4,1400,680,80,{tint:C.white});
    T(d,1440,796,'Local File\nStorage',27); T(d,1440,870,'uploads/ +\nmail outbox',19,{strokeColor:G});
  });
  let groq;
  d.group(()=>{
    groq=d.rect(1650,420,240,250,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white});
    d.lib(S,19,1700,436,140,{dropText:true,tint:C.blueF});
    T(d,1770,544,'Groq API',32); T(d,1770,590,'external · Chat\nCompletions API',21,{strokeColor:G});
  });
  // actor arrows
  d.arrow([[212,300],[350,400]],{to:web,color:C.blue}); label(d,262,250,'uses\nbrowser',C.blue,20);
  d.arrow([[212,640],[350,610]],{to:web,color:C.blue});
  // web -> api
  d.arrow([[670,500],[840,500]],{from:web,to:api,color:C.blue});
  label(d,755,414,'REST / JSON\nsession cookie\nGET /uploads/*',C.blue,20);
  // api -> db
  d.arrow([[1190,360],[1330,360]],{from:api,to:db,color:C.blue}); label(d,1260,292,'SQL via\nDrizzle',C.blue,20);
  d.arrow([[1190,700],[1330,760]],{from:api,to:files,color:C.blue}); label(d,1245,778,'read / write\nimages, mail',C.blue,20);
  // api -> groq
  d.arrow([[1190,545],[1640,545]],{from:api,to:groq,color:C.blue});
  label(d,1415,478,'HTTPS · chat completions\n(text + photo prompts)',C.blue,20);
  d.arrow([[1640,590],[1190,590]],{color:C.green}); label(d,1415,598,'scores, questions, replies',C.green,20);
  legend(d,40,880,[[C.blue,'request / data'],[C.green,'result returned']]);
  d.text(60,1010,'Dev setup shown: Vite dev server (:5174) proxies /api and /uploads to the API (:5102). Production hosting is not defined in the repository.',20,{strokeColor:G});
  fs.writeFileSync(OUT+'/02-container.excalidraw',JSON.stringify(d.json(),null,1));
}

// ======================= C3 =======================
{
  const d=new Doc(); title(d,'Component Diagram','API Server (Node.js + Express 5)  ·  Designed using the C4 Model',200);
  const cx=[330,770,1210], W3=380, H3=146, ry=[330,534,758];
  const comp=(c,r,name,lines,fill)=>{
    let rect; d.group(()=>{
      rect=d.rect(cx[c],ry[r],W3,H3,{backgroundColor:fill});
      T(d,cx[c]+W3/2,ry[r]+10,name,26);
      T(d,cx[c]+W3/2,ry[r]+48,lines.join('\n'),20,{strokeColor:'#374151'});
    }); return rect;
  };
  // boundary + frame
  d.rect(300,150,1320,870,{strokeStyle:'dashed',strokeColor:C.gray});
  d.text(325,160,'API Server   [container: Node.js + Express 5, port 5102]',24,{strokeColor:G});
  let bar;
  d.group(()=>{
    bar=d.rect(330,200,1260,78,{backgroundColor:C.grayF});
    T(d,960,206,'Express Pipeline & Access Control',26);
    T(d,960,240,'CORS allow-list · JSON · cookie parser · static /uploads · JWT cookie check (active user) · role guards ADMIN / USER',19,{strokeColor:'#374151'});
  });
  const frame=d.rect(316,312,1288,386,{strokeStyle:'dashed',strokeColor:'#cbd5e1',strokeWidth:1,roundness:{type:3}});
  const BL=C.blueF, GR=C.greenF;
  const admin=comp(0,0,'Admin Console',['Dashboard stats, Groq config','check, user list,','activate / deactivate users'],BL);
  const auth =comp(1,0,'Auth & Accounts',['Sign-up with OTP e-mail verify,','login (JWT cookie), profile,','password reset'],BL);
  const mail =comp(2,0,'Uploads & Mail',['Image upload (max 5, 5 MB),','contact form, local mail','outbox (no SMTP)'],BL);
  const claims=comp(0,1,'Claims & Handover',['Ownership questions + answer','scoring, claim chat, finder','decision, handover, disputes'],BL);
  const reports=comp(1,1,'Reports & Found Items',['Lost reports, found posts,','public browse and owner','management'],BL);
  const auct =comp(2,1,'Auctions & Alerts',['Public auctions, binding bids,','strikes, admin rules, in-app','notifications'],BL);
  const ai   =comp(0,2,'AI Assistant & Matching',['Athar AI chat, match scores,','claim questions via Groq;','reads photos from disk'],GR);
  const queue=comp(1,2,'AI Job Queue',['PostgreSQL-backed queue,','polled every 5 s: runs match','jobs for items, reports, claims'],GR);
  const sched=comp(2,2,'Scheduler',['Every min: close auctions,','no-shows, finalize handovers','Hourly: notice/start, cleanup'],GR);
  // data bar
  let data;
  d.group(()=>{
    data=d.rect(330,930,1260,70,{backgroundColor:C.grayF});
    T(d,960,935,'Data Access — Drizzle ORM table models',26);
    T(d,960,969,'used by every component: users, lost_reports, found_items, claims, conversations, auctions, bids, ai_processing_jobs …',19,{strokeColor:'#374151'});
  });
  // externals
  let web,groq,pg,fl;
  d.group(()=>{ web=d.rect(30,170,185,130,{backgroundColor:C.blueF}); T(d,122,182,'Web App',28); T(d,122,224,'React SPA\n[container]',20,{strokeColor:G}); });
  d.group(()=>{ groq=d.rect(30,710,185,200,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white});
    d.lib(S,19,57,722,130,{dropText:true,tint:C.blueF}); T(d,122,820,'Groq API',28); T(d,122,858,'external',20,{strokeColor:G}); });
  d.group(()=>{ fl=d.rect(1710,300,190,190,{backgroundColor:C.greenF}); d.lib(W,4,1750,312,70,{tint:C.white}); T(d,1805,420,'Local File\nStorage',24); });
  d.group(()=>{ pg=d.rect(1710,800,190,210,{backgroundColor:C.greenF}); d.lib(W,1,1775,814,60,{tint:C.white}); T(d,1805,925,'PostgreSQL',25); T(d,1805,960,'database',19,{strokeColor:G}); });
  // arrows
  d.arrow([[220,235],[325,235]],{from:web,to:bar,color:C.blue}); label(d,258,188,'REST\nJSON',C.blue,18);
  d.arrow([[960,280],[960,309]],{from:bar,color:C.blue,w:2});
  d.text(975,284,'routes to controllers',19,{strokeColor:G});
  d.arrow([[1165,400],[1205,400]],{from:auth,to:mail,color:C.blue});
  d.arrow([[900,680],[900,754]],{from:reports,to:queue,color:C.blue}); label(d,962,706,'enqueue',C.blue,19);
  d.arrow([[620,680],[840,754]],{from:claims,to:queue,color:C.blue}); label(d,660,716,'enqueue',C.blue,19);
  d.arrow([[520,680],[520,754]],{from:claims,to:ai,color:C.blue}); label(d,452,706,'questions',C.blue,19);
  // claims -> auctions via top gap (elbow)
  d.arrow([[1010,534],[1010,534]].length?[[520,534],[520,508],[1400,508],[1400,534]]:[],{from:claims,to:auct,color:C.blue});
  label(d,960,478,'cancel auction when an owner claim is accepted',C.blue,19);
    d.arrow([[1400,758],[1400,684]],{from:sched,to:auct,color:C.blue}); label(d,1480,706,'auction steps',C.blue,19);
  d.arrow([[1210,832],[1155,832]],{from:sched,to:queue,color:C.blue});
  d.arrow([[770,832],[715,832]],{from:queue,to:ai,color:C.blue});
  // externals
  d.arrow([[1595,400],[1705,400]],{from:mail,to:fl,color:C.blue}); label(d,1650,352,'write\nfiles',C.blue,18);
  d.arrow([[330,832],[221,806]],{from:ai,to:groq,color:C.blue}); label(d,262,764,'HTTPS',C.blue,18);
  d.arrow([[1595,965],[1705,925]],{from:data,to:pg,color:C.blue}); label(d,1650,908,'SQL',C.blue,18);
  d.text(330,1035,'blue = REST feature areas      green = AI & background work',20,{strokeColor:G});
  fs.writeFileSync(OUT+'/03-component.excalidraw',JSON.stringify(d.json(),null,1));
}
console.log('built');
