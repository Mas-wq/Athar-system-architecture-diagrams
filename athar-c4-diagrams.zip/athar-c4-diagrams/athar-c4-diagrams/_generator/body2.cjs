const GRAYD='#9aa1ab';
function ghost(d,x,y,w,h){ return d.rect(x,y,w,h,{strokeStyle:'dashed',strokeColor:GRAYD,backgroundColor:'#fafafa',strokeWidth:2}); }
// ======================= C1 =======================
{
  const d=new Doc(); title(d,'System Context Diagram','Athar Lost & Found Platform  ·  Designed using the C4 Model');
  // Regular user (one account, many activities)
  const ic=d.lib(A,6,155,205,110,{dropText:true,tint:C.grayF});
  T(d,210,205+ic.h+8,'Regular User',30);
  T(d,210,205+ic.h+46,'one account, many activities',20,{strokeColor:G});
  const ay=205+ic.h+82;
  ['Owner · reports a lost item','Finder · reports a found item','Claimant · submits a claim'].forEach((t,i)=>T(d,210,ay+i*30,t,21));
  T(d,210,ay+90,'Seller / Buyer · marketplace *',21,{strokeColor:GRAYD});
  const admin=actor(d,210,690,'Administrator','platform oversight');
  let sys;
  d.group(()=>{
    sys=d.rect(640,230,700,600,{backgroundColor:C.yellow,strokeWidth:3});
    T(d,990,248,'Athar',52); T(d,990,310,'Lost & Found Platform   [software system]',24,{strokeColor:G});
    const area=(y,name,l1,l2,dash)=>{ d.rect(670,y,640,120,{backgroundColor:dash?'#fafafa':C.white,strokeStyle:dash?'dashed':'solid',strokeColor:dash?GRAYD:C.ink,strokeWidth:2});
      d.text(690,y+10,name,28,{strokeColor:dash?GRAYD:C.ink}); d.text(690,y+50,l1+'\n'+l2,21,{strokeColor:dash?GRAYD:'#374151'}); };
    area(370,'Lost & Found','Lost reports and found posts, public browse,','AI-suggested matches (text + photos)');
    area(510,'Claim Management','Claimant answers AI questions; finder decides;','claim chat and handover coordination');
    area(650,'Marketplace (Buy & Sell) *','Seller lists items: price > 0 EGP, or 0 = free;','Buyer purchases. Not found in provided source.',true);
  });
  let groq;
  d.group(()=>{
    groq=d.rect(1580,390,300,200,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white});
    d.lib(S,19,1670,402,120,{dropText:true,tint:C.blueF});
    T(d,1730,490,'AI Service',34); T(d,1730,535,'external AI service\ntext + photo analysis',21,{strokeColor:G});
  });
  d.arrow([[330,300],[625,345]],{to:sys,color:C.blue}); label(d,470,232,'reports, claims,\nchat messages',C.blue);
  d.arrow([[625,445],[330,375]],{color:C.green}); label(d,495,455,'AI match suggestions,\nchat messages',C.green);
  d.arrow([[330,720],[625,690]],{color:C.blue}); label(d,480,640,'manages users',C.blue);
  d.arrow([[625,770],[330,775]],{color:C.green}); label(d,480,783,'dashboard statistics',C.green);
  d.arrow([[1355,450],[1565,450]],{color:C.blue}); label(d,1460,372,'descriptions\n+ photos',C.blue);
  d.arrow([[1565,540],[1355,540]],{color:C.green}); label(d,1460,555,'match scores, questions,\nreplies',C.green);
  note(d,640,870,700,70,'AI only suggests — the finder makes\nthe final ownership decision.',24);
  d.text(60,985,'* Dashed = required by the business logic, but no marketplace code (routes, tables, pages, donation or purchase flow) exists in the uploaded source.',20,{strokeColor:G});
  legend(d,1430,830,[[C.blue,'request / data sent'],[C.green,'result returned']]);
  fs.writeFileSync(OUT+'/01-system-context.excalidraw',JSON.stringify(d.json(),null,1));
}
// ======================= C2 =======================
{
  const d=new Doc(); title(d,'Container Diagram','Athar Lost & Found Platform  ·  Designed using the C4 Model');
  const ic=d.lib(A,6,90,215,110,{dropText:true,tint:C.grayF}); T(d,145,215+ic.h+8,'Regular User',26);
  T(d,145,215+ic.h+42,'owner · finder · claimant\nseller · buyer *',19,{strokeColor:G});
  const admin=actor(d,145,600,'Administrator','platform oversight');
  d.rect(320,190,1260,790,{strokeStyle:'dashed',strokeColor:C.gray,strokeWidth:2});
  d.text(345,202,'Athar Platform   [software system]',24,{strokeColor:G});
  let web,api,db,files,redis,groq;
  d.group(()=>{
    web=d.rect(360,320,300,330,{backgroundColor:C.blueF});
    d.lib(W,5,435,338,150,{tint:C.grayF});
    T(d,510,450,'Web App',34); T(d,510,500,'what users see',21,{strokeColor:G});
    T(d,510,560,'Screens for users\nand administrators',22);
  });
  d.group(()=>{
    api=d.rect(850,260,330,470,{backgroundColor:C.yellow,strokeWidth:3});
    const i2=d.lib(A,9,990,280,60,{dropText:true,tint:C.white});
    T(d,1015,280+i2.h+8,'API Server',34); T(d,1015,280+i2.h+50,'the central server',21,{strokeColor:G});
    ['Handles all requests','Live chat','Login and permissions','Business rules','Background AI jobs','Serves uploaded photos'].forEach((t,k)=>T(d,1015,280+i2.h+92+k*32,t,21));
  });
  d.group(()=>{ db=d.rect(1340,225,200,230,{backgroundColor:C.greenF}); d.lib(W,1,1405,241,70,{tint:C.white});
    T(d,1440,380,'Database',27); T(d,1440,414,'all app data',20,{strokeColor:G}); });
  d.group(()=>{ files=d.rect(1340,665,200,262,{backgroundColor:C.greenF}); d.lib(W,4,1400,680,80,{tint:C.white});
    T(d,1440,796,'File\nStorage',27); T(d,1440,870,'photos and\nemails',19,{strokeColor:G}); });
  d.group(()=>{ redis=d.rect(880,790,270,160,{backgroundColor:C.orangeF});
    d.lib(S,13,900,800,55,{dropText:true,tint:C.white});
    T(d,1060,806,'Chat Memory',26); T(d,1015,868,'recent chat messages\n(kept temporarily)',19,{strokeColor:G}); });
  d.group(()=>{ groq=d.rect(1650,420,240,250,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white});
    d.lib(S,19,1700,436,140,{dropText:true,tint:C.blueF}); T(d,1770,544,'AI Service',30); T(d,1770,590,'external',21,{strokeColor:G}); });
  // marketplace ghost
  d.group(()=>{ ghost(d,360,740,440,210);
    T(d,580,752,'Marketplace (Buy & Sell) *',26,{strokeColor:GRAYD});
    T(d,580,800,'Sell, donate or buy items',21,{strokeColor:GRAYD});
    T(d,580,850,'Not found in the\nprovided source',21,{strokeColor:GRAYD}); });
  d.arrow([[212,285],[350,380]],{to:web,color:C.blue}); label(d,262,236,'uses\nbrowser',C.blue,20);
  d.arrow([[212,640],[350,590]],{to:web,color:C.blue});
  d.arrow([[670,440],[840,440]],{from:web,to:api,color:C.blue});
  label(d,755,348,'requests and\nresponses',C.blue,20);
  d.arrow([[670,560],[840,560]],{from:web,to:api,color:C.blue,start:'arrow'});
  label(d,755,572,'live chat',C.blue,20);
  d.arrow([[1190,340],[1330,340]],{from:api,to:db,color:C.blue}); label(d,1260,272,'read / write\ndata',C.blue,20);
  d.arrow([[1190,700],[1330,760]],{from:api,to:files,color:C.blue}); label(d,1245,778,'photos and\nemails',C.blue,20);
  d.arrow([[1015,735],[1015,785]],{from:api,to:redis,color:C.blue}); label(d,1120,744,'chat history',C.blue,20);
  d.arrow([[1190,545],[1640,545]],{from:api,to:groq,color:C.blue}); label(d,1415,478,'text and photos\nfor analysis',C.blue,20);
  d.arrow([[1640,590],[1190,590]],{color:C.green}); label(d,1415,598,'scores, questions,\nreplies',C.green,20);
  legend(d,40,860,[[C.blue,'request / data'],[C.green,'result returned']]);
  d.text(60,995,'* Dashed = required by the business logic but absent from the uploaded source.',20,{strokeColor:G});
  fs.writeFileSync(OUT+'/02-container.excalidraw',JSON.stringify(d.json(),null,1));
}
// ======================= C3 =======================
{
  const d=new Doc(); title(d,'Component Diagram','API Server  ·  Designed using the C4 Model',200);
  const cx=[330,770,1210], W3=380, H3=132, ry=[300,484,668];
  const comp=(c,r,name,lines,fill)=>{ let rect; d.group(()=>{ rect=d.rect(cx[c],ry[r],W3,H3,{backgroundColor:fill});
      T(d,cx[c]+W3/2,ry[r]+8,name,25); T(d,cx[c]+W3/2,ry[r]+42,lines.join('\n'),19.5,{strokeColor:'#374151'}); }); return rect; };
  d.rect(300,150,1320,860,{strokeStyle:'dashed',strokeColor:C.gray});
  d.text(325,160,'API Server   [container]',24,{strokeColor:G});
  let bar; d.group(()=>{ bar=d.rect(330,198,1260,72,{backgroundColor:C.grayF});
    T(d,960,204,'Request Gatekeeper',25);
    T(d,960,238,'checks login and permissions on every request',20,{strokeColor:'#374151'}); });
  d.rect(316,284,1288,346,{strokeStyle:'dashed',strokeColor:'#cbd5e1',strokeWidth:1,roundness:{type:3}});
  const BL=C.blueF, GR=C.greenF;
  const admin=comp(0,0,'Admin Console',['Manage users and','view platform statistics'],BL);
  const auth =comp(1,0,'Auth & Accounts',['Sign-up, login, profile','and password reset'],BL);
  const mail =comp(2,0,'Uploads & Mail',['Photo uploads and','email messages'],BL);
  const claims=comp(0,1,'Claims & Handover',['Claims with AI questions,','finder decision, handover'],BL);
  const reports=comp(1,1,'Reports & Found Items',['Lost reports, found items','and browsing'],BL);
  const chat =comp(2,1,'Chat & Notifications',['Live claim chat','and notifications'],BL);
  const ai   =comp(0,2,'AI Assistant & Matching',['Suggests matches and','creates claim questions'],GR);
  const queue=comp(1,2,'AI Job Queue',['Runs AI matching','in the background'],GR);
  const sched=comp(2,2,'Scheduler',['Timed tasks: close handovers,','clean unverified sign-ups'],GR);
  let mk; d.group(()=>{ mk=ghost(d,330,815,1260,64);
    T(d,960,820,'Marketplace (Buy & Sell) *  — not found in provided source',24,{strokeColor:GRAYD});
    T(d,960,851,'selling, donating and buying features',19,{strokeColor:GRAYD}); });
  let data; d.group(()=>{ data=d.rect(330,893,1260,70,{backgroundColor:C.grayF});
    T(d,960,898,'Data Access',25);
    T(d,960,932,'reads and writes the database',19,{strokeColor:'#374151'}); });
  let web,groq,pg,fl,rd;
  d.group(()=>{ web=d.rect(30,170,185,130,{backgroundColor:C.blueF}); T(d,122,182,'Web App',28); T(d,122,224,'users and admins\n[container]',19,{strokeColor:G}); });
  d.group(()=>{ groq=d.rect(30,620,185,200,{strokeStyle:'dashed',strokeColor:C.gray,backgroundColor:C.white});
    d.lib(S,19,57,632,130,{dropText:true,tint:C.blueF}); T(d,122,730,'AI Service',26); T(d,122,768,'external',20,{strokeColor:G}); });
  d.group(()=>{ fl=d.rect(1710,260,190,190,{backgroundColor:C.greenF}); d.lib(W,4,1750,272,70,{tint:C.white}); T(d,1805,380,'File\nStorage',24); });
  d.group(()=>{ rd=d.rect(1710,490,190,190,{backgroundColor:C.orangeF}); d.lib(S,13,1760,502,70,{dropText:true,tint:C.white}); T(d,1805,610,'Chat Memory',24); T(d,1805,644,'recent chats',19,{strokeColor:G}); });
  d.group(()=>{ pg=d.rect(1710,740,190,210,{backgroundColor:C.greenF}); d.lib(W,1,1775,754,60,{tint:C.white}); T(d,1805,865,'Database',25); T(d,1805,900,'all app data',19,{strokeColor:G}); });
  d.arrow([[220,235],[325,235]],{from:web,to:bar,color:C.blue}); label(d,258,185,'requests',C.blue,18);
  d.arrow([[960,272],[960,297]],{from:bar,color:C.blue});
  d.text(975,274,'routes each request',19,{strokeColor:G});
  d.arrow([[1165,366],[1205,366]],{from:auth,to:mail,color:C.blue});
  d.arrow([[900,616],[900,664]],{from:reports,to:queue,color:C.blue}); label(d,962,632,'enqueue',C.blue,19);
  d.arrow([[620,616],[840,664]],{from:claims,to:queue,color:C.blue}); label(d,660,642,'enqueue',C.blue,19);
  d.arrow([[520,616],[520,664]],{from:claims,to:ai,color:C.blue}); label(d,452,632,'questions',C.blue,19);
  d.arrow([[1165,786],[1165,786]].length?[[1210,734],[1155,734]]:[],{color:C.blue}); // placeholder removed below
  d.els.pop();
  d.arrow([[1210,734],[1155,734]],{from:sched,to:queue,color:C.blue});
  d.arrow([[770,734],[715,734]],{from:queue,to:ai,color:C.blue});
  // claims -> chat via top gap: system messages
  d.arrow([[430,484],[430,458],[1300,458],[1300,484]],{from:claims,to:chat,color:C.blue});
  label(d,860,430,'status messages',C.blue,19);
  d.arrow([[1595,366],[1705,366]],{from:mail,to:fl,color:C.blue}); label(d,1650,318,'files',C.blue,18);
  d.arrow([[1595,550],[1705,570]],{from:chat,to:rd,color:C.blue}); label(d,1650,508,'chats',C.blue,18);
  d.arrow([[330,740],[221,720]],{from:ai,to:groq,color:C.blue}); label(d,262,676,'AI calls',C.blue,18);
  d.arrow([[1595,930],[1705,900]],{from:data,to:pg,color:C.blue}); label(d,1650,860,'data',C.blue,18);
  d.text(330,1022,'blue = user features    green = AI & background work    * dashed = absent from provided source',20,{strokeColor:G});
  fs.writeFileSync(OUT+'/03-component.excalidraw',JSON.stringify(d.json(),null,1));
}
console.log('built');
