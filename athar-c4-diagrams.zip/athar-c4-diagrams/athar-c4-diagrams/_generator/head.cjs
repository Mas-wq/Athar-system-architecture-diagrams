const {Doc,C,base}=require('./xl.cjs'); const fs=require('fs');
const OUT=process.argv[2]; fs.mkdirSync(OUT,{recursive:true});
const A='989b6f93-architecture-diagram-components.excalidrawlib', S='b2a60524-system-design.excalidrawlib', W='ad36ee2c-software-architecture__1_.excalidrawlib';
const G='#6b7280'; // soft gray for secondary text

function title(d,t,sub,ul=420){
  d.text(60,30,t,54,{strokeWidth:1});
  d.text(62,98,sub,26,{strokeColor:G});
  const l=d.add(base('line',{x:62,y:142,width:ul,height:6,points:[[0,0],[ul*0.33,-4],[ul*0.69,3],[ul,-2]],lastCommittedPoint:null,startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:null,strokeColor:C.blue,strokeWidth:2,roughness:2,roundness:{type:2}}));
}
// centered text lines helper
const T=(d,cx,y,t,fs,o={})=>d.text(cx,y,t,fs,{textAlign:'center',...o});
function legend(d,x,y,items){
  items.forEach(([col,txt],i)=>{ d.arrow([[x,y+i*38+14],[x+60,y+i*38+14]],{color:col}); d.text(x+78,y+i*38,txt,21,{strokeColor:G}); });
}
function actor(d,cx,y,name,sub){
  const ic=d.lib(A,6,cx-55,y,110,{dropText:true,tint:C.grayF});
  T(d,cx,y+ic.h+8,name,28); T(d,cx,y+ic.h+44,sub,21,{strokeColor:G});
  return {icon:ic,bottom:y+ic.h+70,rightX:cx+70,top:y,midY:y+ic.h/2};
}
function label(d,cx,y,t,col,fs=21){ return T(d,cx,y,t,fs,{strokeColor:col||C.ink}); }
function note(d,x,y,w,h,t,fs=22){ d.rect(x,y,w,h,{backgroundColor:C.yellow,strokeColor:'#e0b84a',strokeWidth:1,roundness:{type:3}}); T(d,x+w/2,y+(h-(t.split('\n').length*fs*1.25))/2,t,fs); }

