// Render Excalidraw JSON -> SVG using roughjs (same engine as Excalidraw) -> PNG via Playwright
const rough = require('/opt/npm-tools/node_modules/roughjs/bundled/rough.cjs.js');
const fs = require('fs');
const gen = rough.generator();
const FONT = "'Comic Relief','Comic Sans MS',cursive";
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

function dashFor(el){ const w=el.strokeWidth; if(el.strokeStyle==='dashed') return `${w*5},${w*3.5}`; if(el.strokeStyle==='dotted') return `${w*1},${w*3}`; return null; }
function roughOpts(el, fill){
  const sw = el.strokeWidth;
  const o = { seed: el.seed, roughness: el.roughness, stroke: el.strokeColor, strokeWidth: sw, bowing:1, curveFitting:1,
    fillStyle: el.fillStyle==='cross-hatch'?'cross-hatch':(el.fillStyle==='hachure'?'hachure':'solid'),
    fillWeight: sw/2, hachureGap: sw*4, hachureAngle:-41, disableMultiStroke: false };
  if (fill && el.backgroundColor && el.backgroundColor!=='transparent') o.fill = el.backgroundColor;
  return o;
}
function pathsOf(d){ return gen.toPaths(d); }
function pathsSvg(paths, el, dash){
  return paths.map(p=>{
    const isFill = p.fill && p.fill!=='none';
    const stroke = p.stroke==='none'?'none':p.stroke;
    const fill = isFill?p.fill:'none';
    const sw = p.strokeWidth;
    return `<path d="${p.d}" stroke="${stroke}" stroke-width="${sw}" fill="${fill}" stroke-linecap="round" stroke-linejoin="round"${dash&&!isFill?` stroke-dasharray="${dash}"`:''}/>`;
  }).join('');
}
function roundedRectPath(w,h,r){
  r=Math.min(r,w/2,h/2);
  return `M ${r} 0 L ${w-r} 0 Q ${w} 0, ${w} ${r} L ${w} ${h-r} Q ${w} ${h}, ${w-r} ${h} L ${r} ${h} Q 0 ${h}, 0 ${h-r} L 0 ${r} Q 0 0, ${r} 0`;
}
function renderEl(el){
  if (el.isDeleted) return '';
  let inner='';
  const dash = dashFor(el);
  const hasFill = el.backgroundColor && el.backgroundColor!=='transparent';
  const t = el.type==='draw'?'line':el.type;
  if (t==='rectangle'){
    const o=roughOpts(el,true);
    let d;
    if (el.roundness){ const r=Math.min(el.width,el.height)*0.25; d=gen.path(roundedRectPath(el.width,el.height,Math.min(r,32)),o); }
    else d=gen.rectangle(0,0,el.width,el.height,o);
    inner=pathsSvg(pathsOf(d),el,dash);
  } else if (t==='ellipse'){
    const d=gen.ellipse(el.width/2,el.height/2,el.width,el.height,roughOpts(el,true)); inner=pathsSvg(pathsOf(d),el,dash);
  } else if (t==='diamond'){
    const w=el.width,h=el.height; const d=gen.polygon([[w/2,0],[w,h/2],[w/2,h],[0,h/2]],roughOpts(el,true)); inner=pathsSvg(pathsOf(d),el,dash);
  } else if (t==='line' || t==='arrow'){
    const pts=el.points; const o=roughOpts(el,false);
    const closed = pts.length>2 && Math.abs(pts[0][0]-pts[pts.length-1][0])<2 && Math.abs(pts[0][1]-pts[pts.length-1][1])<2;
    if (t==='line' && closed && hasFill){ const o2=roughOpts(el,true); const d= el.roundness? gen.curve(pts,o2): gen.polygon(pts,o2); inner=pathsSvg(pathsOf(d),el,dash); }
    else {
      let d;
      if (pts.length===2) d=gen.line(pts[0][0],pts[0][1],pts[1][0],pts[1][1],o);
      else if (el.roundness) d=gen.curve(pts,o); else d=gen.linearPath(pts,o);
      inner=pathsSvg(pathsOf(d),el,dash);
    }
    if (t==='arrow'){
      const head=(p,q,kind)=>{ // arrowhead at p, direction from q to p
        const ang=Math.atan2(p[1]-q[1],p[0]-q[0]);
        const len=Math.min(24, Math.max(14, Math.hypot(p[0]-q[0],p[1]-q[1])*0.5)); const a=Math.PI/180*22;
        const x1=p[0]-len*Math.cos(ang-a), y1=p[1]-len*Math.sin(ang-a), x2=p[0]-len*Math.cos(ang+a), y2=p[1]-len*Math.sin(ang+a);
        const o3={...o, strokeLineDash:undefined, seed:el.seed+7};
        return pathsSvg(pathsOf(gen.line(x1,y1,p[0],p[1],o3)),el,null)+pathsSvg(pathsOf(gen.line(x2,y2,p[0],p[1],{...o3,seed:el.seed+9})),el,null);
      };
      if (el.endArrowhead) inner+=head(pts[pts.length-1],pts[pts.length-2],el.endArrowhead);
      if (el.startArrowhead) inner+=head(pts[0],pts[1],el.startArrowhead);
    }
  } else if (t==='text'){
    const lines=el.text.split('\n'); const lh=el.fontSize*(el.lineHeight||1.25);
    const anchor= el.textAlign==='center'?'middle':(el.textAlign==='right'?'end':'start');
    const ax = el.textAlign==='center'? el.width/2 : (el.textAlign==='right'? el.width : 0);
    inner=`<text font-family="${FONT}" font-size="${el.fontSize}" fill="${el.strokeColor}" text-anchor="${anchor}" dominant-baseline="central">`+
      lines.map((l,i)=>`<tspan x="${ax}" y="${lh*i+lh/2}" xml:space="preserve">${esc(l)}</tspan>`).join('')+`</text>`;
  }
  const rot = el.angle? ` rotate(${el.angle*180/Math.PI} ${el.width/2} ${el.height/2})`:'';
  return `<g transform="translate(${el.x} ${el.y})${rot}" opacity="${(el.opacity??100)/100}">${inner}</g>`;
}
function toSvg(doc, W=1920, H=1080){
  const body=doc.elements.map(renderEl).join('\n');
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="#ffffff"/>${body}</svg>`;
}
module.exports={toSvg,FONT};
if (require.main===module){
  (async()=>{
    const {chromium}=require('/opt/npm-tools/node_modules/playwright');
    const [,, inFile, outBase, scaleArg] = process.argv; const scale=+(scaleArg||2);
    const doc=JSON.parse(fs.readFileSync(inFile,'utf8'));
    const W=doc.appState?.exportW||1920,H=doc.appState?.exportH||1080;
    const svg=toSvg(doc,W,H); fs.writeFileSync(outBase+'.svg',svg);
    const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:W,height:H},deviceScaleFactor:scale});
    await pg.setContent(`<html><body style="margin:0;background:#fff">${svg}</body></html>`); await pg.evaluate(()=>document.fonts.ready); await pg.waitForTimeout(300);
    await pg.screenshot({path:outBase+'.png',clip:{x:0,y:0,width:W,height:H}}); await b.close();
  })();
}
